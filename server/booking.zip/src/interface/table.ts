export interface Table {
    id: number
    name: string
    seats: number
    avalible: boolean
  }
  


  export interface Booking{
      id: number
      date: Date
  }

