
let array={
   1: {name:1,
    data:"hej1"
    },
   2: {name:2,
    data:"hej2"
    },
   3: {name:3,
    data:"hej3"
    },
   4: {name:4,
    data:"hej4"
    }
}
delete array[2];
console.log(array)

console.log(array[1])
/* index > -1 ? allTables[index].seats = table.seats : */